// The file contents for the current environment will overwrite these during build.
// The build system defaults to the local environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.

export const environment = {
    dev: true,
    staging: false,
    pre: false,
    production: false,
    apiBaseUrl: 'http://localhost:3000/',
    urlFrames: {
        'executive_clients': 'http://localhost:8001',
        'executive_commercial_activity': 'http://localhost:8002',
        'executive_mon': 'http://localhost:8003',
        'executive_navbar': 'http://localhost:8004',
        'executive_profile': 'http://localhost:8005',
        'executive_quality': 'http://localhost:8006',
        'executive_wallet': 'http://localhost:8007'
    }
};
