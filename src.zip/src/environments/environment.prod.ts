export const environment = {
  dev: false,
  staging: false,
  pre: false,
  production: true,
  apiBaseUrl: ''
};
