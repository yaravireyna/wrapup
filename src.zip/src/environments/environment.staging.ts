export const environment = {
    dev: false,
    staging: true,
    pre: false,
    production: false,
    apiBaseUrl: 'https://neo-db-mxportalunicocc-dev.appls.cto1.paas.gsnetcloud.corp/'
};
