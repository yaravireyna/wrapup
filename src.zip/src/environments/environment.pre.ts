export const environment = {
  dev: false,
  staging: false,
  pre: true,
  production: false,
  apiBaseUrl: ''
};
