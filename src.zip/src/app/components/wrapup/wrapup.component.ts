import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  /* tslint:disable */ selector: 'client-wrapup',
  templateUrl: './wrapup.component.html',
  styleUrls: ['./wrapup.component.scss']
})
export class WrapupComponent  {
    public grb1select:boolean = false;
    public grb2select:boolean = false;
    public grb3select:boolean = false;
    public grb4select:boolean = false;
    public txtfull:boolean = false;
    public isComplete:boolean= false;
    public isSelected: any;
   
    public titulos: string []=['ORIGEN', 'CANAL', 'TIPO DE GESTIÓN', 'MOTIVO/PRODUCTO'];
    public etiquetas: string [][]= [['Agenda', 'Bitácora', 'Campaña', 'Actividad C.', 'Origen', 'Origen', 'Origen', 'Origen'],
                                    ['SuperLínea', 'SuperNet', 'SuperMóvil', 'ATM', 'Canal', 'Canal', 'Canal', 'Canal'],
                                    ['Consumo', 'Venta', 'Incidencia', 'Servicios', 'Tipo', 'Tipo', 'Tipo', 'Tipo'],
                                    ['Producto',  'Producto', 'Producto', 'Producto', 'Producto', 'Producto', 'Producto', 'Producto']];

    @Output() change: EventEmitter<any> = new EventEmitter<any>();
    @Output() sendSelected: EventEmitter<any> = new EventEmitter<any>();
    
    
   
    
    
  
    constructor() { }
    save() {
        /* tslint:disable */ let message = {
            appName: 'neo_client_wrapup',
            type: 'event',
            name: 'closeWrapup',
            data: {}
        };
        window.parent.postMessage(message, '*');
    }

   
    setradio (group, rb){
        let gpo=group+1;
        let rbu=rb+1;
        
        if (gpo == 1) 
        {
            this.grb1select = true;
        }

        if (gpo==2)
        {
            this.grb2select = true;           
        }
        
        if (gpo == 3) 
        {
            this.grb3select = true;           
        }

        if (gpo==4)
        {
            this.grb4select = true;           
        }
    }

   
    public valueChanged() {
        if (this.isSelected != ""){
            this.txtfull= true;
            return true;
        	
		} else {
            this.txtfull= true;
            return false;
        }
    } 
    
    public validaT(){
        if (this.isSelected == ""){
            this.txtfull=false;
        } else {
            this.txtfull=true;
        }
    }

    public validaO() {
        if (this.isSelected != ""){
            this.txtfull=true;
        } else {
            this.txtfull=false;
        }
    }
    
    
    public complete (){
        
        if (this.grb1select && this.grb2select && this.grb3select && this.grb4select && this.txtfull){
            return true;
            
        } else {
            return false;
        }
        
    }
    
    public clean (form: NgForm){
        form.resetForm(); // or form.reset();

    }
}
