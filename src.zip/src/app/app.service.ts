import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

import { environment } from '../environments/environment';


@Injectable()
export class AppService {

    private url: string;

    constructor(private _http: Http) {
        this.url = environment.apiBaseUrl;
    }

    getHttp(uri: string, page?: number, limit?: number): any {
        let queryParams = '?';

        queryParams = page ? queryParams + '&_page=' + page : queryParams;
        queryParams = limit ? queryParams + '&_limit=' + limit : queryParams;

        /* tslint:disable */ let url = this.url + uri + queryParams;

        return this._http.get(url).toPromise().then(response => response.json());
    }
}
