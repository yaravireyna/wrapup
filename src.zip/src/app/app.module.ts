import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpModule } from '@angular/http';
import { TextareaComponent } from 'neo_supplies/elements/textarea/textarea.component';


// Services
import { AppService } from './app.service';

// Components
import { AppComponent } from './app.component';
import { WrapupComponent } from './components/wrapup/wrapup.component';



@NgModule({
  declarations: [
    AppComponent,
    WrapupComponent,
    TextareaComponent
    
  ],
  imports: [
    NgbModule.forRoot(),
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    HttpModule
    
    

  ],
  providers: [
    AppService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
